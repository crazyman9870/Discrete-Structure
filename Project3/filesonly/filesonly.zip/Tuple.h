/*
 * Tuple.h
 *
 *  Created on: Jul 21, 2014
 *      Author: aconstan
 */

#ifndef TUPLE_H_
#define TUPLE_H_

#include <string>
#include <vector>

using namespace std;

class Tuple : public vector<string>
{
public:
	Tuple()
	{

	}
	virtual ~Tuple()
	{

	}
};

#endif /* TUPLE_H_ */
